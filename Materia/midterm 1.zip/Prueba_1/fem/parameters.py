# fem/parameters.py

globalParameters = {
    'nDoF': 2
}
